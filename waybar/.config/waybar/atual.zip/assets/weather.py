#!/usr/bin/env python3

import json
import urllib.parse
import urllib.request


CITY = "americana"

# Ajuste fino: se o valor vier deslocado de um jeito constante,
# dá pra compensar aqui (ex.: -5 se sempre vier 5 a mais)
CALIBRATION_OFFSET = 0


def get_json(url):
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "Waybar"}
    )

    with urllib.request.urlopen(req, timeout=10) as response:
        return json.load(response)


def icon(code):
    if code == 0:
        return "☀"

    if code in (1, 2):
        return "󰖕"

    if code == 3:
        return ""

    if code in (45, 48):
        return "󰖑"

    if 51 <= code <= 67:
        return "󰖗"

    if 71 <= code <= 77:
        return ""

    if 80 <= code <= 82:
        return "󰖖"

    if 95 <= code <= 99:
        return ""

    return ""


try:
    city = urllib.parse.quote(CITY)

    geo = get_json(
        "https://geocoding-api.open-meteo.com/v1/search"
        f"?name={city}&count=1&language=en&format=json"
    )

    result = geo["results"][0]

    lat = result["latitude"]
    lon = result["longitude"]
    city_name = result["name"]

    data = get_json(
        "https://api.open-meteo.com/v1/forecast"
        f"?latitude={lat}"
        f"&longitude={lon}"
        "&current=temperature_2m,apparent_temperature,weather_code"
        "&temperature_unit=celsius"
        "&models=gfs_seamless"
    )

    current = data["current"]

    temp = round(current["temperature_2m"]) + CALIBRATION_OFFSET
    feels = round(current["apparent_temperature"]) + CALIBRATION_OFFSET
    code = current["weather_code"]

    print(json.dumps({
        "text": f"󰖐 {icon(code)} {temp}°C",
        "tooltip": f"{city_name}\nTemperature: {temp}°C\nFeels like: {feels}°C"
    }))

except Exception as e:
    print(json.dumps({
        "text": "Weather N/A",
        "tooltip": str(e)
    }))
