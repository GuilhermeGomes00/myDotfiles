#!/usr/bin/env python3

import json
import subprocess
import time


def run(cmd):
    try:
        return subprocess.check_output(
            cmd,
            stderr=subprocess.DEVNULL,
            text=True
        ).strip()
    except subprocess.CalledProcessError:
        return ""


def get_players():
    output = run(["playerctl", "-l"])

    if not output:
        return []

    return output.splitlines()


def get_status(player):
    return run([
        "playerctl",
        "-p",
        player,
        "status"
    ])


def get_artist(player):
    return run([
        "playerctl",
        "-p",
        player,
        "metadata",
        "xesam:artist"
    ])


def choose_player(players):
    if not players:
        return None

    # Prioriza player que estiver tocando
    for player in players:
        if get_status(player) == "Playing":
            return player

    # Depois algum pausado
    for player in players:
        if get_status(player) == "Paused":
            return player

    return players[0]


def output_player():
    players = get_players()
    player = choose_player(players)

    if not player:
        print(json.dumps({
            "text": "",
            "class": "inactive"
        }), flush=True)
        return

    player_class = player.split(".")[0]

    if player_class == "spotify":
        icon = ""

    elif player_class == "firefox":
        icon = ""

    else:
        print(json.dumps({
            "text": "",
            "class": "inactive"
        }), flush=True)
        return

    status = get_status(player)
    artist = get_artist(player)

    print(json.dumps({
        "text": f"{artist} - {icon}" if artist else icon,
        "class": [
            "media",
            player_class,
            status.lower()
        ],
        "alt": player_class
    }), flush=True)


while True:
    output_player()
    time.sleep(1)
